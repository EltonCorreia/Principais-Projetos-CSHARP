﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRJ_QuestionVR4
{
    public partial class Form3 : Form
    {
        // Lista para armazenar as perguntas e respostas
        private ArrayList perguntasERespostas = new ArrayList();
        // Variável para armazenar a resposta correta da pergunta atual
        private string respostaCorreta;
        public Form3()
        {
            InitializeComponent();

            // Adiciona perguntas e respostas à lista
            perguntasERespostas.Add(new string[] { "Qual é o nome da linguagem de programação desenvolvida por Guido van Rossum?", "Python", "Java", "C++", "Ruby", "A" });
            perguntasERespostas.Add(new string[] { "O que significa a sigla 'HTML'?", "Hyper Text Markup Language", "Hyperlinks and Text Markup Language", "Home Tool Markup Language", "Hyperlinking Text Marking Language", "A" });
            perguntasERespostas.Add(new string[] { "Qual empresa desenvolveu o sistema operacional Windows?", "Apple", "IBM", "Microsoft", "Google", "C" });
            perguntasERespostas.Add(new string[] { "O que é um algoritmo?", "Uma linguagem de programação", "Um tipo de computador", "Uma sequência de instruções", "Um software de sistema", "C" });
            perguntasERespostas.Add(new string[] { "Qual é o principal componente eletrônico em microprocessadores?", "Transistor", "Capacitor", "Resistor", "Diodo", "A" });
            perguntasERespostas.Add(new string[] { "O que é 'byte'?", "Um tipo de bug", "Uma unidade de medida de armazenamento de dados", "Um protocolo de rede", "Uma linguagem de programação", "B" });
            perguntasERespostas.Add(new string[] { "Qual é a linguagem de programação usada para criar scripts em páginas web?", "HTML", "CSS", "JavaScript", "SQL", "C" });
            perguntasERespostas.Add(new string[] { "O que é uma 'nuvem' na computação?", "Um tipo de malware", "Um servidor local", "Armazenamento e processamento de dados na internet", "Uma rede local", "C" });
            perguntasERespostas.Add(new string[] { "O que significa 'RAM'?", "Read Access Memory", "Random Access Memory", "Readily Available Memory", "Randomly Available Memory", "B" });
            perguntasERespostas.Add(new string[] { "Quem é conhecido como o 'pai da computação'?", "Bill Gates", "Steve Jobs", "Alan Turing", "Charles Babbage", "D" });

            // Evento Load do formulário
            this.Load += new EventHandler(Form3_Load);

        }

        private void Form3_Load(object sender, EventArgs e)
        {
            ExibirPerguntaAleatoria();
        }

        private void ExibirPerguntaAleatoria()
        {
            // Seleciona uma pergunta aleatória da lista
            Random random = new Random();
            int index = random.Next(perguntasERespostas.Count);
            string[] perguntaSelecionada = (string[])perguntasERespostas[index];

            // Exibe a pergunta e as respostas no formulário
            lblPergunta.Text = perguntaSelecionada[0];
            rdb1.Text = perguntaSelecionada[1];
            rdb2.Text = perguntaSelecionada[2];
            rdb3.Text = perguntaSelecionada[3];
            rdb4.Text = perguntaSelecionada[4];

            // Armazena a resposta correta
            respostaCorreta = perguntaSelecionada[5];
        }

        private void btnResposta_Click(object sender, EventArgs e)
        {
            // Verifica qual radio button está selecionado e compara com a resposta correta
            string respostaEscolhida = "";
            if (rdb1.Checked) respostaEscolhida = "A";
            else if (rdb2.Checked) respostaEscolhida = "B";
            else if (rdb3.Checked) respostaEscolhida = "C";
            else if (rdb4.Checked) respostaEscolhida = "D";

            if (respostaEscolhida == respostaCorreta)
            {
                MessageBox.Show("Você acertou!");
            }
            else
            {
                MessageBox.Show("Você errou!");
            }

        }
    }
}
