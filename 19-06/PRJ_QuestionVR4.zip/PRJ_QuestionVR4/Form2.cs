﻿using System;
using System.Collections;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace PRJ_QuestionVR4
{
    public partial class Form2 : Form
    {
        // Lista para armazenar as perguntas e respostas
        private ArrayList perguntasERespostas = new ArrayList();
        // Variável para armazenar a resposta correta da pergunta atual
        private string respostaCorreta;
        public Form2()
        {
            InitializeComponent();

            // Adiciona perguntas e respostas à lista
            perguntasERespostas.Add(new string[] { "Quem é o deus do mar na mitologia grega?", "Poseidon", "Zeus", "Hades", "Apolo", "A" });
            perguntasERespostas.Add(new string[] { "Qual é o nome da deusa da sabedoria na mitologia grega?", "Atena", "Deméter", "Afrodite", "Hera", "A" });
            perguntasERespostas.Add(new string[] { "Quem é o mensageiro dos deuses na mitologia grega?", "Hermes", "Apolo", "Dionísio", "Ares", "A" });
            perguntasERespostas.Add(new string[] { "Qual é o nome do titã que foi condenado a segurar o céu?", "Atlas", "Prometeu", "Cronos", "Érebo", "A" });
            perguntasERespostas.Add(new string[] { "Quem é conhecido como o deus do sol na mitologia grega?", "Apolo", "Hélios", "Dionísio", "Hermes", "B" });
            perguntasERespostas.Add(new string[] { "Qual é o nome do rio que, na mitologia grega, os mortos devem atravessar para chegar ao mundo dos mortos?", "Styx", "Aqueronte", "Letes", "Flegetonte", "B" });
            perguntasERespostas.Add(new string[] { "Qual é o nome da deusa da agricultura na mitologia grega?", "Deméter", "Hera", "Ártemis", "Afrodite", "A" });
            perguntasERespostas.Add(new string[] { "Quem é a deusa do amor e da beleza na mitologia grega?", "Afrodite", "Atena", "Hera", "Deméter", "A" });
            perguntasERespostas.Add(new string[] { "Qual é o nome do rei dos deuses na mitologia grega?", "Zeus", "Poseidon", "Hades", "Apolo", "A" });
            perguntasERespostas.Add(new string[] { "Qual é o nome do labirinto construído por Dédalo, onde vivia o Minotauro?", "Labirinto de Creta", "Labirinto de Esparta", "Labirinto de Atenas", "Labirinto de Tebas", "A" });

            // Evento Load do formulário
            this.Load += new EventHandler(Form2_Load);
        }


        private void Form2_Load(object sender, EventArgs e)
        {
            ExibirPerguntaAleatoria();
        }

        private void ExibirPerguntaAleatoria()
        {
            // Seleciona uma pergunta aleatória da lista
            Random random = new Random();
            int index = random.Next(perguntasERespostas.Count);
            string[] perguntaSelecionada = (string[])perguntasERespostas[index];

            // Exibe a pergunta e as respostas no formulário
            lblPergunta.Text = perguntaSelecionada[0];
            rdb1.Text = perguntaSelecionada[1];
            rdb2.Text = perguntaSelecionada[2];
            rdb3.Text = perguntaSelecionada[3];
            rdb4.Text = perguntaSelecionada[4];

            // Armazena a resposta correta
            respostaCorreta = perguntaSelecionada[5];
        }

        private void btnResposta_Click(object sender, EventArgs e)
        {
            // Verifica qual radio button está selecionado e compara com a resposta correta
            string respostaEscolhida = "";
            if (rdb1.Checked) respostaEscolhida = "A";
            else if (rdb2.Checked) respostaEscolhida = "B";
            else if (rdb3.Checked) respostaEscolhida = "C";
            else if (rdb4.Checked) respostaEscolhida = "D";

            if (respostaEscolhida == respostaCorreta)
            {
                MessageBox.Show("Você acertou!");
            }
            else
            {
                MessageBox.Show("Você errou!");
            }

        }

        private void btnProximo_Click(object sender, EventArgs e)
        {
            Form3 frn3 = new Form3();
            frn3.ShowDialog();
        }
    }
}
