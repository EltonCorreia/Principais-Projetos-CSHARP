using System.Collections;
using System.Runtime.Intrinsics.Arm;

namespace PRJ_QuestionVR4
{
    public partial class Form1 : Form
    {
        // Lista para armazenar as perguntas e respostas
        private ArrayList perguntasERespostas = new ArrayList();
        // Vari�vel para armazenar a resposta correta da pergunta atual
        private string respostaCorreta;

        public Form1()
        {
            InitializeComponent();
            // Adiciona perguntas e respostas � lista
            perguntasERespostas.Add(new string[] { "Qual � a capital da Fran�a?", "Paris", "Londres", "Berlim", "Madrid", "A" });
            perguntasERespostas.Add(new string[] { "Qual � a maior floresta tropical do mundo?", "Taiga", "Amaz�nia", "Floresta Negra", "Floresta dos Apalaches", "B" });
            perguntasERespostas.Add(new string[] { "Quem pintou a Mona Lisa?", "Vincent van Gogh", "Pablo Picasso", "Michelangelo", "Leonardo da Vinci", "D" });
            perguntasERespostas.Add(new string[] { "Quantos planetas existem no sistema solar?", "7", "8", "9", "10", "B" });
            perguntasERespostas.Add(new string[] { "Qual � o maior oceano do mundo?", "Oceano Atl�ntico", "Oceano �ndico", "Oceano �rtico", "Oceano Pac�fico", "D" });
            perguntasERespostas.Add(new string[] { "Quem escreveu 'Dom Quixote'?", "William Shakespeare", "Miguel de Cervantes", "J.K. Rowling", "George Orwell", "B" });
            perguntasERespostas.Add(new string[] { "Qual � o elemento qu�mico representado pelo s�mbolo 'O'?", "Ouro", "Osmio", "Oxig�nio", "�smio", "C" });
            perguntasERespostas.Add(new string[] { "Qual � a montanha mais alta do mundo?", "Monte Fuji", "Monte Everest", "Mont Blanc", "Monte Kilimanjaro", "B" });
            perguntasERespostas.Add(new string[] { "Quem descobriu a penicilina?", "Marie Curie", "Louis Pasteur", "Alexander Fleming", "Gregor Mendel", "C" });
            perguntasERespostas.Add(new string[] { "Qual � o pa�s mais populoso do mundo?", "�ndia", "China", "Estados Unidos", "Indon�sia", "B" });

            // Evento Load do formul�rio
            this.Load += new EventHandler(Form1_Load);
        }


        private void Form1_Load(object sender, EventArgs e)
        {
            ExibirPerguntaAleatoria();
        }

        private void ExibirPerguntaAleatoria()
        {
            // Seleciona uma pergunta aleat�ria da lista
            Random random = new Random();
            int index = random.Next(perguntasERespostas.Count);
            string[] perguntaSelecionada = (string[])perguntasERespostas[index];

            // Exibe a pergunta e as respostas no formul�rio
            lblPergunta.Text = perguntaSelecionada[0];
            rdb1.Text = perguntaSelecionada[1];
            rdb2.Text = perguntaSelecionada[2];
            rdb3.Text = perguntaSelecionada[3];
            rdb4.Text = perguntaSelecionada[4];

            // Armazena a resposta correta
            respostaCorreta = perguntaSelecionada[5];
        }


        private void btnProximo_Click(object sender, EventArgs e)
        {
            Form2 frn2 = new Form2();
            frn2.ShowDialog();
        }

        private void btnResposta_Click(object sender, EventArgs e)
        {
            // Verifica qual radio button est� selecionado e compara com a resposta correta
            string respostaEscolhida = "";
            if (rdb1.Checked) respostaEscolhida = "A";
            else if (rdb2.Checked) respostaEscolhida = "B";
            else if (rdb3.Checked) respostaEscolhida = "C";
            else if (rdb4.Checked) respostaEscolhida = "D";

            if (respostaEscolhida == respostaCorreta)
            {
                MessageBox.Show("Voc� acertou!");
            }
            else
            {
                MessageBox.Show("Voc� errou!");
            }

        }
    }
}
