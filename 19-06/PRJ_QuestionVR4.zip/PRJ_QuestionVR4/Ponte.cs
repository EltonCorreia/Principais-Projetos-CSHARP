﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace PRJ_QuestionVR4
{ 
// Classe Ponte, que armazena um nome e um contador de forma estática
    public class Ponte
{
    // Variável estática para armazenar o nome
    private static String nome;

    // Variável estática para armazenar o contador
    private static int contador;

    // Método para incrementar o valor do contador
    public void setContar(int i)
    {
        contador += i; // Incrementa o contador com o valor passado como argumento
    }

    // Método para obter o valor atual do contador
    public int getContar()
    {
        return contador; // Retorna o valor do contador
    }

    // Método para definir o valor do nome
    public void setNome(String v)
    {
        nome = v; // Define o valor da variável estática nome com o valor passado como argumento
    }

    // Método para obter o valor atual do nome
    public String getNome()
    {
        return nome; // Retorna o valor da variável estática nome
    }
}
}
