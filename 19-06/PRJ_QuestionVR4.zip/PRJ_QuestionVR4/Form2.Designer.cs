﻿namespace PRJ_QuestionVR4
{
    partial class Form2
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            btnProximo = new Button();
            btnResposta = new Button();
            rdb4 = new RadioButton();
            rdb3 = new RadioButton();
            rdb2 = new RadioButton();
            rdb1 = new RadioButton();
            lblPergunta = new Label();
            SuspendLayout();
            // 
            // btnProximo
            // 
            btnProximo.Location = new Point(849, 128);
            btnProximo.Name = "btnProximo";
            btnProximo.Size = new Size(94, 100);
            btnProximo.TabIndex = 13;
            btnProximo.Text = "Proximo";
            btnProximo.UseVisualStyleBackColor = true;
            btnProximo.Click += btnProximo_Click;
            // 
            // btnResposta
            // 
            btnResposta.Location = new Point(727, 128);
            btnResposta.Name = "btnResposta";
            btnResposta.Size = new Size(94, 100);
            btnResposta.TabIndex = 12;
            btnResposta.Text = "Resposta";
            btnResposta.UseVisualStyleBackColor = true;
            btnResposta.Click += btnResposta_Click;
            // 
            // rdb4
            // 
            rdb4.AutoSize = true;
            rdb4.Location = new Point(411, 190);
            rdb4.Name = "rdb4";
            rdb4.Size = new Size(98, 24);
            rdb4.TabIndex = 11;
            rdb4.TabStop = true;
            rdb4.Text = "Resposta4";
            rdb4.UseVisualStyleBackColor = true;
            // 
            // rdb3
            // 
            rdb3.AutoSize = true;
            rdb3.Location = new Point(411, 128);
            rdb3.Name = "rdb3";
            rdb3.Size = new Size(98, 24);
            rdb3.TabIndex = 10;
            rdb3.TabStop = true;
            rdb3.Text = "Resposta3";
            rdb3.UseVisualStyleBackColor = true;
            // 
            // rdb2
            // 
            rdb2.AutoSize = true;
            rdb2.Location = new Point(94, 190);
            rdb2.Name = "rdb2";
            rdb2.Size = new Size(98, 24);
            rdb2.TabIndex = 9;
            rdb2.TabStop = true;
            rdb2.Text = "Resposta2";
            rdb2.UseVisualStyleBackColor = true;
            // 
            // rdb1
            // 
            rdb1.AutoSize = true;
            rdb1.Location = new Point(94, 128);
            rdb1.Name = "rdb1";
            rdb1.Size = new Size(98, 24);
            rdb1.TabIndex = 8;
            rdb1.TabStop = true;
            rdb1.Text = "Resposta1";
            rdb1.UseVisualStyleBackColor = true;
            // 
            // lblPergunta
            // 
            lblPergunta.AutoSize = true;
            lblPergunta.Location = new Point(87, 85);
            lblPergunta.Name = "lblPergunta";
            lblPergunta.Size = new Size(67, 20);
            lblPergunta.TabIndex = 7;
            lblPergunta.Text = "Pergunta";
            // 
            // Form2
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(1030, 312);
            Controls.Add(btnProximo);
            Controls.Add(btnResposta);
            Controls.Add(rdb4);
            Controls.Add(rdb3);
            Controls.Add(rdb2);
            Controls.Add(rdb1);
            Controls.Add(lblPergunta);
            Name = "Form2";
            Text = "Form2";
            Load += Form2_Load;
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button btnProximo;
        private Button btnResposta;
        private RadioButton rdb4;
        private RadioButton rdb3;
        private RadioButton rdb2;
        private RadioButton rdb1;
        private Label lblPergunta;
    }
}